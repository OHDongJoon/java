package com.lec.ch19.dto;

import lombok.Data;

@Data
public class Member {
	private String mid;
	private String mpw;
	private String mname;
	private String mmail;
	private String mpost;
	private String maddr;
 
}
